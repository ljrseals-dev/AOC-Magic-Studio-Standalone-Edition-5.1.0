"""AOC Magic Studio, standalone edition: numpy-only audio engine (speech, vocal arrangement, mixing, MIDI, pitch)."""
__version__ = "5.1.0"
EDITION = "standalone"
