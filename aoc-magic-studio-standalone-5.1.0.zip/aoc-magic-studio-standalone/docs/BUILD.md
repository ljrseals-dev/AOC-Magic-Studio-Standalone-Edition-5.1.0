# Building and distributing

**Run from source:** `pip install numpy` then `python -m aoc ...`.

**One-file app (verified):** `python tools/build_pyz.py` -> `dist/aoc.pyz` (about 41 KB). Run `python aoc.pyz ...` on any
machine with Python 3.9+ and numpy. Exit codes are preserved. Tested here by `tests/test_build.py`.

**Bundled executable (NOT built or tested here):** `pip install pyinstaller numpy` then `pyinstaller aoc.spec` on each
target OS (PyInstaller does not cross-compile). Expect the size to be dominated by numpy (here: about 6.3 MB zipped,
21.3 MB installed for numpy 2.4.4 on Linux/CPython 3.12). Use the executable's own `doctor` command to check it.
Alternatives: Nuitka, or embedding the official Python "embeddable" zip plus numpy wheels on Windows.

**Python wheel:** `pip install .` uses `pyproject.toml` (not exercised here).

**Tests:** `python tools/run_tests.py` (no pytest needed) or `pytest -q tests`.
