import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np


def raises(exc, fn):
    try:
        fn()
    except exc:
        return True
    raise AssertionError(f"expected {exc.__name__}")


def tmp():
    return tempfile.mkdtemp(prefix="aoc_test_")


def fundamental(y, sr, lo=40, hi=800):
    seg = y[: min(len(y), 8820)]
    ac = np.correlate(seg, seg, "full")[len(seg) - 1:]
    lag = int(np.argmax(ac[int(sr / hi):int(sr / lo)])) + int(sr / hi)
    return sr / lag


def peak_freq(y, sr):
    Y = np.abs(np.fft.rfft(y * np.hanning(len(y))))
    return float(np.fft.rfftfreq(len(y), 1 / sr)[Y.argmax()])
