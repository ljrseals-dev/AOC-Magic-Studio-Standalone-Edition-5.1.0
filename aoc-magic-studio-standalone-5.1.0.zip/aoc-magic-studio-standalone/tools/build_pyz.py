#!/usr/bin/env python3
"""Build dist/aoc.pyz: one runnable file containing the whole app (pure Python). Needs numpy on the target machine.

    python tools/build_pyz.py            ->  dist/aoc.pyz
    python dist/aoc.pyz doctor
"""
import shutil, sys, tempfile, zipapp
from pathlib import Path

root = Path(__file__).resolve().parent.parent
out = root / "dist" / "aoc.pyz"
out.parent.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as t:
    stage = Path(t) / "app"
    shutil.copytree(root / "aoc", stage / "aoc", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    (stage / "__main__.py").write_text("import sys\nfrom aoc.cli import main\nsys.exit(main())\n")
    zipapp.create_archive(stage, out, interpreter="/usr/bin/env python3", compressed=True)
print(f"built {out} ({out.stat().st_size / 1024:.0f} KB). Requires: python3 >= 3.9 and numpy.")
